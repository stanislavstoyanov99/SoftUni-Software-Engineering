﻿namespace CarDealer.Data
{
    public static class DataConfiguration
    {
        public const string DefaultConnection 
            = @"Server=DESKTOP-ANG7ES6\SQLEXPRESS;Database=CarDealer;Trusted_Connection=True;";
    }
}
