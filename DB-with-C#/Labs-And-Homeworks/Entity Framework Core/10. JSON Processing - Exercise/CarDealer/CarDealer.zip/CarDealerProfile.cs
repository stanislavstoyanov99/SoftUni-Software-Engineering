﻿using System;
using System.Text;
using System.Collections.Generic;

using AutoMapper;

using CarDealer.Models;

namespace CarDealer
{
    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
        
        }
    }
}
