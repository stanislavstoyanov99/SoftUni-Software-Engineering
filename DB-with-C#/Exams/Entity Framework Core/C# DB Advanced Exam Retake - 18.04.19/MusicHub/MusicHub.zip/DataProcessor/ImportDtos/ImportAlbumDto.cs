﻿namespace MusicHub.DataProcessor.ImportDtos
{
    public class ImportAlbumDto
    {
        public string Name { get; set; }

        public string ReleaseDate { get; set; }
    }
}
