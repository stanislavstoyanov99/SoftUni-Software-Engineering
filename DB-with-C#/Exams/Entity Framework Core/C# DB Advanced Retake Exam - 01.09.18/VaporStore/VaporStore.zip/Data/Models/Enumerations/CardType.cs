﻿namespace VaporStore.Data.Models.Enumerations
{
    public enum CardType
    {
        Debit = 0,
        Credit = 1
    }
}
