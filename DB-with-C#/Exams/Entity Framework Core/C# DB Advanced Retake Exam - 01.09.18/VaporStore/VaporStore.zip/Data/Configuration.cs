﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=DESKTOP-ANG7ES6\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}