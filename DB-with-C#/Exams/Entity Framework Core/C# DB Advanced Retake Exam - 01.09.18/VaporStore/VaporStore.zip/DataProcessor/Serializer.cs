﻿namespace VaporStore.DataProcessor
{
	using System;
	using Data;

	public static class Serializer
	{
		public static string ExportGamesByGenres(VaporStoreDbContext context, string[] genreNames)
		{
            return null;
        }

		public static string ExportUserPurchasesByType(VaporStoreDbContext context, string storeType)
		{
            return null;
        }
	}
}