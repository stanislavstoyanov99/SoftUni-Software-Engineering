﻿namespace VaporStore.DataProcessor.ImportDtos
{
    public class ImportCardDto
    {
        public string Number { get; set; }

        public string CVC { get; set; }

        public string Type { get; set; }
    }
}
