﻿namespace SoftJail.DataProcessor
{
    using System;

    using Data;

    public class Bonus
    {
        public static string ReleasePrisoner(SoftJailDbContext context, int prisonerId)
        {
            return null;
        }
    }
}
